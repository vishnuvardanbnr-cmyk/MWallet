import { useState, useRef, useEffect, useCallback } from "react";
import { HelpCircle, Mail, ChevronDown, Plus, Send, ArrowLeft, MessageCircle, Clock, CheckCircle2, AlertCircle, Loader2, Ticket, Zap, TrendingUp, RefreshCw } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PACKAGE_NAMES, PACKAGE_PRICES_USD } from "@/lib/contract";
import { useSupportWs } from "@/hooks/use-support-ws";
import type { SupportTicket, TicketMessage } from "@shared/schema";

const ADMIN_WALLET = "0x04e8c5b49de683c5b44ef1269bd5ee4f338868c4";

const faqs = [
  {
    question: "How do I register?",
    answer: "To register, connect your MetaMask wallet on BNB Smart Chain. You will need a sponsor ID and a binary parent ID. Your sponsor provides the referral link containing these details. Once connected, follow the on-screen registration process and approve the required token transaction.",
  },
  {
    question: "What are the package tiers?",
    answer: `There are 5 package tiers available: ${PACKAGE_NAMES.slice(1).map((name, i) => `${name} ($${PACKAGE_PRICES_USD[i + 1]})`).join(", ")}. Higher packages unlock greater income limits and earning potential. You can upgrade your package at any time.`,
  },
  {
    question: "How does binary matching income work?",
    answer: "Binary matching income is calculated by matching the business volume on your left and right legs. The system pairs the lesser leg volume against the greater and calculates your binary commission based on the matched amount. Unmatched volume carries forward to the next cycle.",
  },
  {
    question: "What is the BTC Reward Pool?",
    answer: "The BTC Pool accumulates 10% from every MVT sell. This balance is used exclusively to enter Board Pool Level 1 — it cannot be directly withdrawn. Once you enter the board and the matrix fills, you earn rewards (40% of the pool) credited directly to your withdrawable USDT balance.",
  },
  {
    question: "How do withdrawals work?",
    answer: "You can withdraw your wallet balance at any time. A 10% withdrawal matching fee is deducted and distributed to upline sponsors, and an additional 10% is allocated to the BTC Reward Pool. The remaining 80% is transferred directly to your wallet as USDT.",
  },
  {
    question: "What is the grace period?",
    answer: "The grace period is a status assigned to accounts that have been inactive beyond the allowed time frame. During this period, certain earning functions may be limited. To restore full active status, you may need to repurchase or upgrade your package.",
  },
];

const CATEGORIES = [
  { value: "general", label: "General" },
  { value: "account", label: "Account" },
  { value: "staking", label: "Staking" },
  { value: "withdrawal", label: "Withdrawal" },
  { value: "technical", label: "Technical" },
  { value: "other", label: "Other" },
];

function getStatusColor(status: string) {
  switch (status) {
    case "open": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/20";
    case "in_progress": return "text-blue-400 bg-blue-500/10 border-blue-500/20";
    case "closed": return "text-gray-400 bg-gray-500/10 border-gray-500/20";
    default: return "text-gray-400 bg-gray-500/10 border-gray-500/20";
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case "open": return <AlertCircle className="h-3 w-3" />;
    case "in_progress": return <Clock className="h-3 w-3" />;
    case "closed": return <CheckCircle2 className="h-3 w-3" />;
    default: return <Clock className="h-3 w-3" />;
  }
}

function formatTime(date: string | Date) {
  const d = new Date(date);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString();
}

interface SupportProps {
  account: string;
  isAdmin?: boolean;
}

function NewTicketForm({ onSubmit, onCancel }: { onSubmit: (subject: string, category: string, message: string, priority: string) => void; onCancel: () => void }) {
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("general");
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState("normal");

  const handleSubmit = () => {
    if (!subject.trim() || !message.trim()) return;
    onSubmit(subject.trim(), category, message.trim(), priority);
  };

  return (
    <div className="glass-card rounded-2xl p-6 slide-in gradient-border" data-testid="card-new-ticket">
      <div className="flex items-center gap-3 mb-6">
        <div className="h-9 w-9 rounded-xl bg-emerald-500/15 flex items-center justify-center">
          <Plus className="h-4 w-4 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-lg font-bold gradient-text" style={{ fontFamily: 'var(--font-display)' }}>New Support Ticket</h2>
          <p className="text-xs text-muted-foreground">Describe your issue and we'll help you out</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm text-muted-foreground">Subject</label>
          <Input
            placeholder="Brief description of your issue"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="bg-white/[0.03] border-yellow-600/20"
            data-testid="input-ticket-subject"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Category</label>
            <Select value={category} onValueChange={setCategory} data-testid="select-ticket-category">
              <SelectTrigger className="bg-white/[0.03] border-yellow-600/20" data-testid="select-ticket-category">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map(c => (
                  <SelectItem key={c.value} value={c.value} data-testid={`category-option-${c.value}`}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Priority</label>
            <Select value={priority} onValueChange={setPriority} data-testid="select-ticket-priority">
              <SelectTrigger className="bg-white/[0.03] border-yellow-600/20" data-testid="select-ticket-priority">
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low" data-testid="priority-option-low">Low</SelectItem>
                <SelectItem value="normal" data-testid="priority-option-normal">Normal</SelectItem>
                <SelectItem value="high" data-testid="priority-option-high">High</SelectItem>
                <SelectItem value="urgent" data-testid="priority-option-urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-muted-foreground">Message</label>
          <textarea
            placeholder="Describe your issue in detail..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 rounded-md bg-white/[0.03] border border-yellow-600/20 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-purple-500/30"
            data-testid="input-ticket-message"
          />
        </div>

        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 px-4 rounded-xl border border-yellow-600/20 text-sm font-medium text-muted-foreground hover:bg-white/[0.03] transition-colors"
            data-testid="button-cancel-ticket"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!subject.trim() || !message.trim()}
            className="flex-1 glow-button text-white font-bold py-2.5 px-4 rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            data-testid="button-submit-ticket"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            <Send className="h-4 w-4" />
            Submit Ticket
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatView({ messages, ticket, account, onSend, onBack, onClose, onReopen, isAdmin }: {
  messages: TicketMessage[];
  ticket: SupportTicket;
  account: string;
  onSend: (msg: string) => void;
  onBack: () => void;
  onClose: (id: number) => void;
  onReopen: (id: number) => void;
  isAdmin: boolean;
}) {
  const [input, setInput] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    onSend(input.trim());
    setInput("");
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden slide-in gradient-border flex flex-col" style={{ height: "calc(100vh - 220px)", minHeight: "400px" }} data-testid="card-chat">
      <div className="p-4 border-b border-yellow-600/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="h-8 w-8 rounded-lg bg-white/[0.05] flex items-center justify-center hover:bg-white/[0.08] transition-colors"
            data-testid="button-back-tickets"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold" style={{ fontFamily: 'var(--font-display)' }} data-testid="text-ticket-subject">{ticket.subject}</h3>
              <Badge variant="outline" className={`text-[10px] ${getStatusColor(ticket.status)}`} data-testid="badge-ticket-status">
                {getStatusIcon(ticket.status)}
                <span className="ml-1">{ticket.status.replace("_", " ")}</span>
              </Badge>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Ticket #{ticket.id} &middot; {ticket.category} &middot; {formatTime(ticket.createdAt)}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          {isAdmin && ticket.status !== "closed" && (
            <button
              onClick={() => onClose(ticket.id)}
              className="text-[11px] px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors"
              data-testid="button-close-ticket"
            >
              Close Ticket
            </button>
          )}
          {ticket.status === "closed" && (
            <button
              onClick={() => onReopen(ticket.id)}
              className="text-[11px] px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
              data-testid="button-reopen-ticket"
            >
              Reopen
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3" data-testid="chat-messages">
        {messages.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm">
            <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p>No messages yet</p>
          </div>
        )}
        {messages.map((msg) => {
          const isMe = msg.senderWallet.toLowerCase() === account.toLowerCase();
          const isAdminMsg = msg.senderRole === "admin";
          return (
            <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`} data-testid={`message-${msg.id}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                isMe
                  ? "bg-gradient-to-r from-amber-600/20 to-yellow-500/20 border border-yellow-600/20"
                  : isAdminMsg
                    ? "bg-gradient-to-r from-emerald-600/20 to-amber-400/10 border border-emerald-500/20"
                    : "bg-white/[0.05] border border-white/[0.08]"
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[10px] font-medium ${isAdminMsg ? "text-emerald-400" : "text-yellow-300"}`}>
                    {isAdminMsg ? "Support Team" : isMe ? "You" : "User"}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{formatTime(msg.createdAt)}</span>
                </div>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.message}</p>
              </div>
            </div>
          );
        })}
        <div ref={chatEndRef} />
      </div>

      {ticket.status !== "closed" && (
        <div className="p-3 border-t border-yellow-600/10">
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="bg-white/[0.03] border-yellow-600/20"
              data-testid="input-chat-message"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="glow-button text-white px-4 rounded-xl transition-all disabled:opacity-50 flex items-center justify-center"
              data-testid="button-send-message"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function TicketList({ tickets, onSelect, onNewTicket, isAdmin = false }: { tickets: SupportTicket[]; onSelect: (id: number) => void; onNewTicket: () => void; isAdmin?: boolean }) {
  return (
    <div className="glass-card rounded-2xl p-6 slide-in gradient-border" style={{ animationDelay: '0.15s' }} data-testid="card-tickets">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-yellow-600/15 flex items-center justify-center">
            <Ticket className="h-4 w-4 text-yellow-300" />
          </div>
          <div>
            <h2 className="text-lg font-bold gradient-text" style={{ fontFamily: 'var(--font-display)' }}>My Tickets</h2>
            <p className="text-xs text-muted-foreground">{tickets.length} ticket{tickets.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
        <button
          onClick={onNewTicket}
          className="glow-button text-white text-sm font-medium py-2 px-4 rounded-xl transition-all flex items-center gap-2"
          data-testid="button-new-ticket"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          <Plus className="h-4 w-4" />
          New Ticket
        </button>
      </div>

      {tickets.length === 0 ? (
        <div className="text-center py-8" data-testid="text-no-tickets">
          <MessageCircle className="h-10 w-10 text-muted-foreground/20 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">No tickets yet</p>
          <p className="text-xs text-muted-foreground/60 mt-1">Create a new ticket to get help from our support team</p>
        </div>
      ) : (
        <div className="space-y-2">
          {tickets.map((ticket) => (
            <button
              key={ticket.id}
              onClick={() => onSelect(ticket.id)}
              className="w-full p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-transparent hover:border-yellow-600/10 transition-all text-left group"
              data-testid={`ticket-item-${ticket.id}`}
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium group-hover:text-yellow-200 transition-colors">{ticket.subject}</span>
                  <Badge variant="outline" className={`text-[9px] ${getStatusColor(ticket.status)}`}>
                    {getStatusIcon(ticket.status)}
                    <span className="ml-1">{ticket.status.replace("_", " ")}</span>
                  </Badge>
                </div>
                <span className="text-[10px] text-muted-foreground">{formatTime(ticket.updatedAt)}</span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-muted-foreground">#{ticket.id}</span>
                <span className="text-[11px] text-muted-foreground/50">&middot;</span>
                <span className="text-[11px] text-muted-foreground capitalize">{ticket.category}</span>
                {isAdmin && (
                  <>
                    <span className="text-[11px] text-muted-foreground/50">&middot;</span>
                    <span className="text-[11px] font-mono text-yellow-300/70">{ticket.walletAddress.slice(0, 6)}...{ticket.walletAddress.slice(-4)}</span>
                  </>
                )}
                {ticket.priority === "high" || ticket.priority === "urgent" ? (
                  <>
                    <span className="text-[11px] text-muted-foreground/50">&middot;</span>
                    <span className={`text-[11px] ${ticket.priority === "urgent" ? "text-red-400" : "text-orange-400"}`}>
                      {ticket.priority}
                    </span>
                  </>
                ) : null}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminDistribution({ getAdminPoolBalances, distributeBinaryIncome, distributePowerLeg }: {
  getAdminPoolBalances: () => Promise<{ binaryPool: bigint; powerLegReserve: bigint; adminPool: bigint; totalUsers: number }>;
  distributeBinaryIncome: (n: number) => Promise<void>;
  distributePowerLeg: (n: number) => Promise<void>;
}) {
  const [pools, setPools] = useState<{ binaryPool: bigint; powerLegReserve: bigint; adminPool: bigint; totalUsers: number } | null>(null);
  const [loadingPools, setLoadingPools] = useState(false);
  const [step1Loading, setStep1Loading] = useState(false);
  const [step2Loading, setStep2Loading] = useState(false);
  const [step1Done, setStep1Done] = useState(false);
  const [step2Done, setStep2Done] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fmt = (v: bigint) => (Number(v) / 1e18).toFixed(2);

  const load = useCallback(async () => {
    setLoadingPools(true);
    try {
      const data = await getAdminPoolBalances();
      setPools(data);
      // If powerLegReserve > 0, step 1 was already done this cycle
      if (data.powerLegReserve > 0n) setStep1Done(true);
      else setStep1Done(false);
    } catch (e: any) {
      setError(e?.message || "Failed to load pool balances");
    } finally {
      setLoadingPools(false);
    }
  }, [getAdminPoolBalances]);

  useEffect(() => { load(); }, [load]);

  const handleStep1 = async () => {
    if (!pools) return;
    setStep1Loading(true);
    setError(null);
    try {
      await distributeBinaryIncome(pools.totalUsers);
      setStep1Done(true);
      await load();
    } catch (e: any) {
      setError(e?.shortMessage || e?.reason || e?.message || "Transaction failed");
    } finally {
      setStep1Loading(false);
    }
  };

  const handleStep2 = async () => {
    if (!pools) return;
    setStep2Loading(true);
    setError(null);
    try {
      await distributePowerLeg(pools.totalUsers);
      setStep1Done(false);
      setStep2Done(true);
      await load();
    } catch (e: any) {
      setError(e?.shortMessage || e?.reason || e?.message || "Transaction failed");
    } finally {
      setStep2Loading(false);
    }
  };

  const binaryReady = pools && pools.binaryPool > 0n && !step1Done;
  const powerReady  = pools && pools.powerLegReserve > 0n && step1Done;

  return (
    <div className="glass-card rounded-2xl p-5 slide-in gradient-border space-y-4" data-testid="card-admin-distribution">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-purple-500/15 flex items-center justify-center">
            <Zap className="h-4 w-4 text-purple-400" />
          </div>
          <div>
            <h2 className="text-base font-bold gradient-text" style={{ fontFamily: "var(--font-display)" }}>Binary & Power Leg Distribution</h2>
            <p className="text-xs text-muted-foreground">Run Step 1 then Step 2 each cycle</p>
          </div>
        </div>
        <button onClick={load} disabled={loadingPools} className="h-8 w-8 rounded-lg bg-white/[0.05] flex items-center justify-center hover:bg-white/[0.08] transition-colors" data-testid="button-refresh-pools">
          <RefreshCw className={`h-3.5 w-3.5 text-muted-foreground ${loadingPools ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Pool balances */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/15 text-center">
          <p className="text-[10px] text-amber-300/70 uppercase tracking-wider mb-1">Binary Pool</p>
          <p className="text-sm font-bold text-amber-300" data-testid="text-binary-pool">${pools ? fmt(pools.binaryPool) : "—"}</p>
        </div>
        <div className="p-3 rounded-xl bg-violet-500/5 border border-violet-500/15 text-center">
          <p className="text-[10px] text-violet-300/70 uppercase tracking-wider mb-1">Power Leg Reserve</p>
          <p className="text-sm font-bold text-violet-300" data-testid="text-power-reserve">${pools ? fmt(pools.powerLegReserve) : "—"}</p>
        </div>
        <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/15 text-center">
          <p className="text-[10px] text-emerald-300/70 uppercase tracking-wider mb-1">Total Users</p>
          <p className="text-sm font-bold text-emerald-300" data-testid="text-total-users">{pools ? pools.totalUsers : "—"}</p>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400" data-testid="text-distribution-error">{error}</div>
      )}

      {/* Step 1 */}
      <div className="flex items-center gap-3">
        <div className={`flex-shrink-0 h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${step1Done ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"}`}>
          {step1Done ? "✓" : "1"}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">Distribute Binary Income</p>
          <p className="text-[11px] text-muted-foreground">70% to matched pairs · sets Power Leg Points</p>
        </div>
        <button
          onClick={handleStep1}
          disabled={!binaryReady || step1Loading}
          className="flex-shrink-0 px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500/15 border border-amber-500/25 text-amber-300 hover:bg-amber-500/25 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
          data-testid="button-distribute-binary"
        >
          {step1Loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <TrendingUp className="h-3 w-3" />}
          {step1Loading ? "Running…" : "Run Step 1"}
        </button>
      </div>

      {/* Step 2 */}
      <div className="flex items-center gap-3">
        <div className={`flex-shrink-0 h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${step2Done ? "bg-emerald-500/20 text-emerald-400" : "bg-violet-500/20 text-violet-400"}`}>
          {step2Done ? "✓" : "2"}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">Distribute Power Leg</p>
          <p className="text-[11px] text-muted-foreground">30% proportional to Power Leg Points · resets cycle</p>
        </div>
        <button
          onClick={handleStep2}
          disabled={!powerReady || step2Loading}
          className="flex-shrink-0 px-4 py-2 rounded-xl text-xs font-semibold bg-violet-500/15 border border-violet-500/25 text-violet-300 hover:bg-violet-500/25 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
          data-testid="button-distribute-powerleg"
        >
          {step2Loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
          {step2Loading ? "Running…" : "Run Step 2"}
        </button>
      </div>

      {step2Done && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 text-center" data-testid="text-cycle-complete">
          Cycle complete — both distributions done. Pool is ready for the next cycle.
        </div>
      )}
    </div>
  );
}

export default function Support({ account, isAdmin = false, getAdminPoolBalances, distributeBinaryIncome, distributePowerLeg }: SupportProps) {
  const [view, setView] = useState<"list" | "new" | "chat">("list");
  const ws = useSupportWs(account, isAdmin);

  const activeTicket = ws.tickets.find(t => t.id === ws.activeTicketId);

  useEffect(() => {
    if (ws.ticketCreated && ws.activeTicketId) {
      setView("chat");
    }
  }, [ws.ticketCreated, ws.activeTicketId]);

  const handleSelectTicket = (id: number) => {
    ws.joinTicket(id);
    setView("chat");
  };

  const handleBack = () => {
    ws.leaveTicket();
    ws.loadTickets();
    setView("list");
  };

  const handleCreateTicket = (subject: string, category: string, message: string, priority: string) => {
    ws.createTicket(subject, category, message, priority);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 relative z-10">
      <div className="slide-in">
        <h1 className="text-2xl font-bold gradient-text" data-testid="text-support-title" style={{ fontFamily: 'var(--font-display)' }}>Help & Support</h1>
        <p className="text-muted-foreground text-sm">
          {view === "chat" ? "Live chat with support" : "Get help with your account"}
          {ws.connected && (
            <span className="inline-flex items-center gap-1 ml-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] text-emerald-400">Live</span>
            </span>
          )}
        </p>
      </div>

      {view === "list" && (
        <>
          {isAdmin && getAdminPoolBalances && distributeBinaryIncome && distributePowerLeg && (
            <AdminDistribution
              getAdminPoolBalances={getAdminPoolBalances}
              distributeBinaryIncome={distributeBinaryIncome}
              distributePowerLeg={distributePowerLeg}
            />
          )}

          <TicketList
            tickets={ws.tickets}
            onSelect={handleSelectTicket}
            onNewTicket={() => setView("new")}
            isAdmin={isAdmin}
          />

          <div className="glass-card rounded-2xl p-6 slide-in" style={{ animationDelay: '0.2s' }} data-testid="card-faq">
            <div className="flex items-center gap-3 mb-6">
              <div className="h-9 w-9 rounded-xl gradient-icon flex items-center justify-center">
                <HelpCircle className="h-4 w-4 text-yellow-300" />
              </div>
              <div>
                <h2 className="text-lg font-bold gradient-text" style={{ fontFamily: 'var(--font-display)' }}>FAQ</h2>
                <p className="text-xs text-muted-foreground">Common questions about the platform</p>
              </div>
            </div>
            <Accordion type="single" collapsible className="w-full" data-testid="accordion-faq">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="border-yellow-600/10" data-testid={`faq-item-${index}`}>
                  <AccordionTrigger className="text-sm hover:no-underline" data-testid={`faq-trigger-${index}`}>{faq.question}</AccordionTrigger>
                  <AccordionContent data-testid={`faq-content-${index}`}>
                    <p className="text-muted-foreground text-sm">{faq.answer}</p>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </>
      )}

      {view === "new" && (
        <NewTicketForm
          onSubmit={handleCreateTicket}
          onCancel={() => setView("list")}
        />
      )}

      {view === "chat" && activeTicket && (
        <ChatView
          messages={ws.messages}
          ticket={activeTicket}
          account={account}
          onSend={ws.sendMessage}
          onBack={handleBack}
          onClose={ws.closeTicket}
          onReopen={ws.reopenTicket}
          isAdmin={isAdmin}
        />
      )}
    </div>
  );
}
